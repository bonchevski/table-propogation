"use client";

import { useMemo, useState } from "react";
import { LicenseManager } from "@ag-grid-enterprise/core";
import { AgGridReact } from "@ag-grid-community/react";
import "./ag-grid.css";
import "./ag-theme-quartz.css";
import { ClientSideRowModelModule } from "@ag-grid-community/client-side-row-model";
import { ColDef, ModuleRegistry } from "@ag-grid-community/core";
import { ColumnsToolPanelModule } from "@ag-grid-enterprise/column-tool-panel";
import { MenuModule } from "@ag-grid-enterprise/menu";
import { RowGroupingModule } from "@ag-grid-enterprise/row-grouping";

LicenseManager.setLicenseKey(
  "Using_this_{AG_Grid}_Enterprise_key_{AG-064629}_in_excess_of_the_licence_granted_is_not_permitted___Please_report_misuse_to_legal@ag-grid.com___For_help_with_changing_this_key_please_contact_info@ag-grid.com___{Clarasight_PBC}_is_granted_a_{Single_Application}_Developer_License_for_the_application_{Clarasight_PBC}_only_for_{2}_Front-End_JavaScript_developers___All_Front-End_JavaScript_developers_working_on_{Clarasight_PBC}_need_to_be_licensed___{Clarasight_PBC}_has_been_granted_a_Deployment_License_Add-on_for_{1}_Production_Environment___This_key_works_with_{AG_Grid}_Enterprise_versions_released_before_{6_August_2025}____[v3]_[01]_MTc1NDQzNDgwMDAwMA==b1c3148685e3c17298700954a66b1e3a"
);

ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  ColumnsToolPanelModule,
  MenuModule,
  RowGroupingModule,
]);
const GridExample = () => {
    // Row data for the main event and subgroups
    const rowData = [
      {
        eventName: 'Annual Kickoff',
        startDate: '02/04/2025',
        location: 'London, UK',
        headcount: 6600,
        emissions: 5280000,
        groupName: 'Berlin Office',
        origin: 'BER',
        travelMethod: 'Air',
        travelClass: 'Business',
        groupHeadcount: 780,
        groupEmissions: 624000,
        subGroups: [
          { groupName: 'Partners', origin: 'BER', travelMethod: 'Air', travelClass: 'First', headcount: 164, emissions: 65000 },
          { groupName: 'Managers', origin: 'BER', travelMethod: 'Air', travelClass: 'Business', headcount: 168, emissions: 67000 },
          { groupName: 'Consultants', origin: 'BER', travelMethod: 'Air', travelClass: 'Business', headcount: 348, emissions: 139200 },
          { groupName: 'Guests', origin: 'BER', travelMethod: 'Air', travelClass: 'Premium', headcount: 100, emissions: 40000 },
        ],
      },
      {
        eventName: 'Annual Kickoff',
        startDate: '02/04/2025',
        location: 'London, UK',
        headcount: 6600,
        emissions: 5280000,
        groupName: 'Dubai Office',
        origin: 'DWC',
        travelMethod: 'Air',
        travelClass: '--',
        groupHeadcount: 690,
        groupEmissions: 1345,
        subGroups: [],
      },
    ];
  
    // Define the column definitions
    const [columnDefs, _setColumnDefs] = useState<ColDef[]>([
      { headerName: 'Group Name', field: 'groupName', sortable: true, rowGroup: true, hide: true },
      { headerName: 'Origin', field: 'origin', sortable: true, cellEditor: 'agSelectCellEditor', cellEditorParams: { values: ['BER', 'DWC'] } },
      { headerName: 'Travel Method', field: 'travelMethod', sortable: true, cellEditor: 'agSelectCellEditor', cellEditorParams: { values: ['Air', 'Train', 'Car'] } },
      { headerName: 'Class', field: 'travelClass', sortable: true, cellEditor: 'agSelectCellEditor', cellEditorParams: { values: ['Business', 'First', 'Premium', '--'] } },
      { headerName: 'Headcount', field: 'headcount', sortable: true },
      { headerName: 'Emissions', field: 'emissions', sortable: true },
    ]);
  
    // Default column settings
    const defaultColDef = {
      sortable: true,
      filter: true,
      editable: true,
      resizable: true,
      flex: 1,
    };
  
    // Auto group column definition for the collapsible rows
    const autoGroupColumnDef = {
      headerName: 'Event Name',
      field: 'eventName',
      cellRendererParams: { suppressCount: true }, // Don't show the group count
    };
  
    // Function to get the detail row data for subgroups
    const getDetailRowData = (params) => {
      params.successCallback(params.data.subGroups);
    };
  
    return (
      <div className="ag-theme-alpine" style={{ height: '600px', width: '100%' }}>
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          masterDetail={true} // Enable master-detail view
          groupDisplayType="groupRows" // Enable grouping and collapsibility
          autoGroupColumnDef={autoGroupColumnDef}
          detailCellRendererParams={{
            detailGridOptions: {
              columnDefs: columnDefs, // Use the same column definitions for sub-groups
              defaultColDef: defaultColDef,
            },
            getDetailRowData: getDetailRowData, // Define function to get sub-group data
          }}
        />
      </div>
    );
  };
  
  export default GridExample;