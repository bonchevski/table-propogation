// types.ts

// Partner Level
export interface Partner {
    partnerName: string;
    contact: string;
  }
  
  // Group Level
  export interface Group {
    groupName: string;
    origin: string;
    travelType: string; // Car, Bus, Plane
    classType: string; // Business, Economy, First Class
    headCount: number;
    emissions: number;
    partners: Partner[]; // this can be anything not just partners but for this example it is partners
    //[key: string]: any; // this is for any additional fields that may be added
  }
  
  // Event Level
  export interface IEvent {
    eventName: string;
    location: string;
    time: string;
    groups: Group[];
  }
  